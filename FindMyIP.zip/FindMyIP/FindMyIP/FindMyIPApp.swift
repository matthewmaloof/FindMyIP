//
//  FindMyIPApp.swift
//  FindMyIP
//
//  Created by Matthew Maloof on 10/30/23.
//

import SwiftUI

@main
struct FindMyIPApp: App {
    var body: some Scene {
        WindowGroup {
            FindMyIPView()
        }
    }
}
